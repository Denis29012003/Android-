package com.apps.gerashchenkolab2

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.navigation.fragment.findNavController
import androidx.recyclerview.widget.LinearLayoutManager
import com.apps.gerashchenkolab2.databinding.FragmentStartBinding


class StartFragment : Fragment() {

    private lateinit var binding: FragmentStartBinding
    val listOfHero = mutableListOf(
        SuperheroModel(
            "https://upload.wikimedia.org/wikipedia/en/a/aa/Hulk_%28circa_2019%29.png",
            "Hulk",
            false,
            "Bruce Banner, a genetics researcher with a tragic past, suffers an accident that causes him to transform into a raging green monster when he gets angry."
        ), SuperheroModel(
            "https://cdn.vox-cdn.com/thumbor/FGRejpFQN3N0ZE9qyd8erd-W3-U=/1400x1050/filters:format(jpeg)/cdn.vox-cdn.com/uploads/chorus_asset/file/10194909/InfinityWar5a4bb0e7cdea1.jpg",
            "Thanos",
            true,
            "Thanos was a genocidal warlord from Titan, whose objective was to bring stability to the universe by wiping out half of all life at every level, as he believed its massive population would inevitably use up the universe's entire supply of resources and perish. "
        )
    )
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?
    ): View {
        binding = FragmentStartBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        binding.recyclers.setHasFixedSize(true)
        binding.recyclers.layoutManager = LinearLayoutManager(requireContext())
        binding.recyclers.adapter = HeroAdapter(
            requireActivity(), listOfHero
        ) {
            val action = StartFragmentDirections.actionStartFragmentToDetailFragment2(listOfHero[it])
            findNavController().navigate(action)
        }
    }
}