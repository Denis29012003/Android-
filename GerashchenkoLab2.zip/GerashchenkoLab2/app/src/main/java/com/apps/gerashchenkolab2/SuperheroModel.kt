package com.apps.gerashchenkolab2

import android.os.Parcelable
import kotlinx.parcelize.Parcelize


@Parcelize
data class SuperheroModel(
    val image:String, val name:String, val isVillian:Boolean, val details:String
): Parcelable
