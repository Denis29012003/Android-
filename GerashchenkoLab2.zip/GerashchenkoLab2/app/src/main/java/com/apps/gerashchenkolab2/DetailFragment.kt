package com.apps.gerashchenkolab2

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.navigation.fragment.findNavController
import com.apps.gerashchenkolab2.databinding.FragmentDetailBinding
import com.bumptech.glide.Glide

class DetailFragment : Fragment() {
    private lateinit var binding: FragmentDetailBinding
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        val dataModel: SuperheroModel? = arguments?.getParcelable("hero")
        binding = FragmentDetailBinding.inflate(inflater, container, false)
        binding.textViewForDetail.text = dataModel?.details
        binding.textViewForName.text = dataModel?.name
        binding.buttonBacktomenu.setOnClickListener {
            val action = dataModel?.let { it1 ->
                DetailFragmentDirections.actionDetailFragmentToStartFragment(
                    it1
                )
            }
            action?.let { it1 -> findNavController().navigate(it1) }
        }
        Glide.with(requireContext())
            .load(dataModel?.image)
            .circleCrop()
            .into(binding.imageForDetail)
        return binding.root
    }
}